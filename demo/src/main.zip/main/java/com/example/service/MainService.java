package com.example.service;

import java.util.ArrayList;
import java.util.List;

import com.example.dto.Member;

public interface MainService {
	public ArrayList<Member> getMember(Member m);
}
